import { Shield, Truck, Award } from 'lucide-react';

interface TrustSectionProps {
  language?: 'FR' | 'EN';
}

export function TrustSection({ language = 'FR' }: TrustSectionProps) {
  const translations = {
    FR: {
      title: 'Pourquoi nous faire confiance ?',
      features: [
        {
          icon: Shield,
          title: 'Paiement sécurisé',
          description: 'Vos transactions sont protégées par des systèmes de paiement fiables'
        },
        {
          icon: Truck,
          title: 'Livraison rapide',
          description: 'Réseau logistique optimisé pour des livraisons dans les meilleurs délais'
        },
        {
          icon: Award,
          title: 'Produits certifiés',
          description: 'Tous nos produits respectent les standards de qualité internationaux'
        }
      ]
    },
    EN: {
      title: 'Why trust us?',
      features: [
        {
          icon: Shield,
          title: 'Secure Payment',
          description: 'Your transactions are protected by reliable payment systems'
        },
        {
          icon: Truck,
          title: 'Fast Delivery',
          description: 'Optimized logistics network for timely deliveries'
        },
        {
          icon: Award,
          title: 'Certified Products',
          description: 'All our products meet international quality standards'
        }
      ]
    }
  };

  const t = translations[language];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 text-foreground">{t.title}</h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {t.features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <feature.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2 text-foreground">{feature.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}