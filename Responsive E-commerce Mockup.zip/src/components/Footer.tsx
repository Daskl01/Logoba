import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from './ui/button';

interface FooterProps {
  language?: 'FR' | 'EN';
}

export function Footer({ language = 'FR' }: FooterProps) {
  const translations = {
    FR: {
      categories: {
        title: 'Catégories',
        items: ['Produits agricoles', 'Intrants & engrais', 'Matériel agricole', 'Stockage & logistique']
      },
      about: {
        title: 'À propos',
        items: ['Notre mission', 'Équipe', 'Partenaires', 'Carrières']
      },
      support: {
        title: 'Support',
        items: ['Centre d\'aide', 'Contact', 'FAQ', 'Conditions d\'utilisation']
      },
      contact: {
        title: 'Contact',
        address: 'Abidjan, Côte d\'Ivoire',
        phone: '+225 XX XX XX XX',
        email: 'contact@logoba.com'
      },
      rights: 'Tous droits réservés',
      description: 'LÔGÔBA connecte les producteurs africains aux marchés internationaux à travers une plateforme numérique innovante.'
    },
    EN: {
      categories: {
        title: 'Categories',
        items: ['Agricultural products', 'Inputs & fertilizers', 'Agricultural equipment', 'Storage & logistics']
      },
      about: {
        title: 'About',
        items: ['Our mission', 'Team', 'Partners', 'Careers']
      },
      support: {
        title: 'Support',
        items: ['Help center', 'Contact', 'FAQ', 'Terms of use']
      },
      contact: {
        title: 'Contact',
        address: 'Abidjan, Côte d\'Ivoire',
        phone: '+225 XX XX XX XX',
        email: 'contact@logoba.com'
      },
      rights: 'All rights reserved',
      description: 'LÔGÔBA connects African producers to international markets through an innovative digital platform.'
    }
  };

  const t = translations[language];

  return (
    <footer className="bg-foreground text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand & Description */}
          <div className="md:col-span-1">
            <h2 className="text-2xl font-bold mb-4">
              LÔG<span className="text-secondary">Ô</span>BA
            </h2>
            <p className="text-gray-300 text-sm leading-relaxed mb-6">
              {t.description}
            </p>
            <div className="flex gap-4">
              <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-white/10">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-white/10">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-white/10">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-white/10">
                <Linkedin className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">{t.categories.title}</h3>
            <ul className="space-y-2">
              {t.categories.items.map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-white text-sm transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* About */}
          <div>
            <h3 className="font-semibold mb-4">{t.about.title}</h3>
            <ul className="space-y-2">
              {t.about.items.map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-white text-sm transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support & Contact */}
          <div>
            <h3 className="font-semibold mb-4">{t.support.title}</h3>
            <ul className="space-y-2 mb-6">
              {t.support.items.map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-white text-sm transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <MapPin className="h-4 w-4" />
                <span>{t.contact.address}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Phone className="h-4 w-4" />
                <span>{t.contact.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Mail className="h-4 w-4" />
                <span>{t.contact.email}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 text-center">
          <p className="text-gray-300 text-sm">
            © 2025 LÔGÔBA. {t.rights}
          </p>
        </div>
      </div>
    </footer>
  );
}