import { ShoppingCart, MapPin, Award } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  currency?: 'FCFA' | 'USD';
  image: string;
  location?: string;
  badges?: string[];
  vendor?: string;
  onAddToCart?: (id: string) => void;
  className?: string;
}

export function ProductCard({
  id,
  name,
  price,
  currency = 'FCFA',
  image,
  location,
  badges = [],
  vendor,
  onAddToCart,
  className = ''
}: ProductCardProps) {
  const formatPrice = (price: number, currency: string) => {
    if (currency === 'FCFA') {
      return `${price.toLocaleString()} FCFA`;
    }
    return `$${price.toFixed(2)}`;
  };

  return (
    <Card className={`group hover:shadow-lg transition-shadow ${className}`}>
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <ImageWithFallback
            src={image}
            alt={name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {badges.length > 0 && (
            <div className="absolute top-2 left-2 flex flex-wrap gap-1">
              {badges.map((badge) => (
                <Badge
                  key={badge}
                  variant="secondary"
                  className="bg-primary/90 text-white text-xs"
                >
                  {badge}
                </Badge>
              ))}
            </div>
          )}
        </div>

        <div className="p-4">
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-medium text-foreground leading-tight line-clamp-2 flex-1">
              {name}
            </h3>
          </div>

          {location && (
            <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2">
              <MapPin className="h-3 w-3" />
              <span>{location}</span>
            </div>
          )}

          {vendor && (
            <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
              <Award className="h-3 w-3" />
              <span>{vendor}</span>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-primary">
                {formatPrice(price, currency)}
              </span>
              {currency === 'FCFA' && (
                <span className="text-sm text-muted-foreground">
                  ${(price / 600).toFixed(2)}
                </span>
              )}
            </div>

            <Button
              size="sm"
              className="bg-primary hover:bg-primary/90"
              onClick={() => onAddToCart?.(id)}
            >
              <ShoppingCart className="h-4 w-4 mr-1" />
              +
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}