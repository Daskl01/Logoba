import { Search, ShoppingCart, User, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface HeaderProps {
  currentLanguage?: 'FR' | 'EN';
  onLanguageChange?: (lang: 'FR' | 'EN') => void;
}

export function Header({ currentLanguage = 'FR', onLanguageChange }: HeaderProps) {
  const translations = {
    FR: {
      search: 'Chercher un produit...',
      login: 'Connexion',
      signup: 'Inscription'
    },
    EN: {
      search: 'Search product...',
      login: 'Log in',
      signup: 'Sign up'
    }
  };

  const t = translations[currentLanguage];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-primary">
              LÔG<span className="text-secondary">Ô</span>BA
            </h1>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-lg mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder={t.search}
                className="pl-10 w-full"
              />
            </div>
          </div>

          {/* Right Section */}
          <div className="flex items-center gap-4">
            {/* Language Selector */}
            <Select value={currentLanguage} onValueChange={onLanguageChange}>
              <SelectTrigger className="w-16 border-none">
                <Globe className="h-4 w-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="FR">FR</SelectItem>
                <SelectItem value="EN">EN</SelectItem>
              </SelectContent>
            </Select>

            {/* Cart */}
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                2
              </span>
            </Button>

            {/* User Menu */}
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                {t.login}
              </Button>
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                {t.signup}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}