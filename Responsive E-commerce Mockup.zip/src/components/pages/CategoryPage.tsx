import { useState } from 'react';
import { Filter, Grid, List, ChevronDown } from 'lucide-react';
import { Header } from '../Header';
import { Footer } from '../Footer';
import { ProductCard } from '../ProductCard';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Checkbox } from '../ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Slider } from '../ui/slider';
import { Badge } from '../ui/badge';

interface CategoryPageProps {
  language?: 'FR' | 'EN';
}

export function CategoryPage({ language = 'FR' }: CategoryPageProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [priceRange, setPriceRange] = useState([0, 20000000]);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

  const translations = {
    FR: {
      title: 'Produits agricoles',
      filters: 'Filtres',
      price: 'Prix (FCFA)',
      origin: 'Origine',
      certification: 'Certification',
      vendor: 'Vendeur',
      clearFilters: 'Effacer les filtres',
      sortBy: 'Trier par',
      results: 'résultats'
    },
    EN: {
      title: 'Agricultural products',
      filters: 'Filters',
      price: 'Price (FCFA)',
      origin: 'Origin',
      certification: 'Certification',
      vendor: 'Vendor',
      clearFilters: 'Clear filters',
      sortBy: 'Sort by',
      results: 'results'
    }
  };

  const t = translations[language];

  const products = [
    {
      id: '1',
      name: 'Cacao premium de Côte d\'Ivoire',
      price: 1200000,
      image: "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Abidjan, CI',
      badges: ['Bio', 'Certifié'],
      vendor: 'Coopérative SCAC'
    },
    {
      id: '2',
      name: 'Noix d\'anacarde calibrées',
      price: 850000,
      image: "https://images.unsplash.com/photo-1594900689460-fdad3599342c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXNoZXclMjBudXRzJTIwYW5hY2FyZGV8ZW58MXx8fHwxNzU3OTQ4Njk5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Bouaké, CI',
      badges: ['Export'],
      vendor: 'ANACARCI'
    },
    {
      id: '3',
      name: 'Café Robusta premium',
      price: 950000,
      image: "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Man, CI',
      badges: ['Bio', 'Commerce équitable'],
      vendor: 'CAFECOOP'
    },
    // Plus de produits...
  ];

  const toggleFilter = (filter: string) => {
    setSelectedFilters(prev => 
      prev.includes(filter) 
        ? prev.filter(f => f !== filter)
        : [...prev, filter]
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Header language={language} />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <div className="lg:w-1/4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  {t.filters}
                </CardTitle>
                {selectedFilters.length > 0 && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSelectedFilters([])}
                    className="text-secondary hover:text-secondary/80"
                  >
                    {t.clearFilters}
                  </Button>
                )}
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Price Range */}
                <div>
                  <h4 className="font-medium mb-3">{t.price}</h4>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    max={20000000}
                    step={100000}
                    className="mb-2"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{priceRange[0].toLocaleString()}</span>
                    <span>{priceRange[1].toLocaleString()}</span>
                  </div>
                </div>

                {/* Origin */}
                <div>
                  <h4 className="font-medium mb-3">{t.origin}</h4>
                  <div className="space-y-2">
                    {['Côte d\'Ivoire', 'Ghana', 'Burkina Faso', 'Mali'].map(origin => (
                      <div key={origin} className="flex items-center space-x-2">
                        <Checkbox 
                          id={origin}
                          checked={selectedFilters.includes(origin)}
                          onCheckedChange={() => toggleFilter(origin)}
                        />
                        <label htmlFor={origin} className="text-sm">{origin}</label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Certification */}
                <div>
                  <h4 className="font-medium mb-3">{t.certification}</h4>
                  <div className="space-y-2">
                    {['Bio', 'Commerce équitable', 'Rainforest Alliance', 'UTZ'].map(cert => (
                      <div key={cert} className="flex items-center space-x-2">
                        <Checkbox 
                          id={cert}
                          checked={selectedFilters.includes(cert)}
                          onCheckedChange={() => toggleFilter(cert)}
                        />
                        <label htmlFor={cert} className="text-sm">{cert}</label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            {/* Header with controls */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div>
                <h1 className="text-3xl font-bold text-foreground">{t.title}</h1>
                <p className="text-muted-foreground">{products.length} {t.results}</p>
              </div>
              
              <div className="flex items-center gap-4">
                <Select defaultValue="popular">
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">Plus populaires</SelectItem>
                    <SelectItem value="price-low">Prix croissant</SelectItem>
                    <SelectItem value="price-high">Prix décroissant</SelectItem>
                    <SelectItem value="newest">Plus récents</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex border rounded-lg">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                    className="rounded-r-none"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className="rounded-l-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Active Filters */}
            {selectedFilters.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedFilters.map(filter => (
                  <Badge 
                    key={filter} 
                    variant="secondary"
                    className="cursor-pointer hover:bg-secondary/80"
                    onClick={() => toggleFilter(filter)}
                  >
                    {filter} ×
                  </Badge>
                ))}
              </div>
            )}

            {/* Product Grid */}
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'md:grid-cols-2 xl:grid-cols-3' 
                : 'grid-cols-1'
            }`}>
              {products.map(product => (
                <ProductCard
                  key={product.id}
                  {...product}
                  className={viewMode === 'list' ? 'flex-row' : ''}
                  onAddToCart={(id) => console.log('Added to cart:', id)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      <Footer language={language} />
    </div>
  );
}