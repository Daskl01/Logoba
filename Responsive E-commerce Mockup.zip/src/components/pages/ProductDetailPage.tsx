import { useState } from 'react';
import { Star, MapPin, Award, Shield, Truck, Minus, Plus, Heart, Share2, ChevronLeft } from 'lucide-react';
import { Header } from '../Header';
import { Footer } from '../Footer';
import { ProductCard } from '../ProductCard';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface ProductDetailPageProps {
  language?: 'FR' | 'EN';
}

export function ProductDetailPage({ language = 'FR' }: ProductDetailPageProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const translations = {
    FR: {
      backToProducts: 'Retour aux produits',
      addToCart: 'Ajouter au panier',
      buyNow: 'Acheter maintenant',
      quantity: 'Quantité',
      description: 'Description',
      specifications: 'Spécifications',
      reviews: 'Avis',
      vendorInfo: 'Informations vendeur',
      similarProducts: 'Produits similaires',
      securePayment: 'Paiement sécurisé',
      fastDelivery: 'Livraison rapide',
      qualityGuarantee: 'Garantie qualité'
    },
    EN: {
      backToProducts: 'Back to products',
      addToCart: 'Add to cart',
      buyNow: 'Buy now',
      quantity: 'Quantity',
      description: 'Description',
      specifications: 'Specifications',
      reviews: 'Reviews',
      vendorInfo: 'Vendor information',
      similarProducts: 'Similar products',
      securePayment: 'Secure payment',
      fastDelivery: 'Fast delivery',
      qualityGuarantee: 'Quality guarantee'
    }
  };

  const t = translations[language];

  const product = {
    id: '1',
    name: 'Cacao premium de Côte d\'Ivoire',
    price: 1200000,
    images: [
      "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    ],
    location: 'Abidjan, Côte d\'Ivoire',
    badges: ['Bio', 'Certifié UTZ', 'Commerce équitable'],
    vendor: {
      name: 'Coopérative SCAC',
      rating: 4.8,
      reviews: 126,
      verified: true,
      location: 'San Pedro, CI'
    },
    description: 'Cacao de qualité supérieure provenant des plantations certifiées de Côte d\'Ivoire. Nos fèves sont séchées naturellement au soleil et triées à la main pour garantir la meilleure qualité. Idéal pour la production de chocolat haut de gamme.',
    specifications: {
      'Origine': 'Côte d\'Ivoire',
      'Variété': 'Trinitario',
      'Taux d\'humidité': '< 7%',
      'Taille des fèves': '100-110 fèves/100g',
      'Certification': 'UTZ, Bio, Commerce équitable',
      'Conditionnement': 'Sacs jute 60kg'
    }
  };

  const similarProducts = [
    {
      id: '2',
      name: 'Cacao bio du Ghana',
      price: 1150000,
      image: "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Kumasi, GH',
      badges: ['Bio'],
      vendor: 'COCOA-GH'
    },
    {
      id: '3',
      name: 'Fèves de cacao fermentées',
      price: 1300000,
      image: "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Douala, CM',
      badges: ['Premium'],
      vendor: 'CACAOCAM'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header language={language} />
      
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-6 text-sm text-muted-foreground">
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            <ChevronLeft className="h-4 w-4 mr-1" />
            {t.backToProducts}
          </Button>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              <ImageWithFallback
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square w-20 rounded-lg overflow-hidden border-2 ${
                    selectedImage === index ? 'border-primary' : 'border-gray-200'
                  }`}
                >
                  <ImageWithFallback
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex flex-wrap gap-2 mb-3">
                {product.badges.map(badge => (
                  <Badge key={badge} className="bg-primary/10 text-primary">
                    {badge}
                  </Badge>
                ))}
              </div>
              <h1 className="text-3xl font-bold text-foreground mb-2">{product.name}</h1>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{product.location}</span>
                </div>
              </div>
            </div>

            {/* Vendor Info */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Award className="h-5 w-5 text-primary" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{product.vendor.name}</span>
                        {product.vendor.verified && (
                          <Badge variant="secondary" className="text-xs">
                            Vérifié
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span>{product.vendor.rating}</span>
                        <span>({product.vendor.reviews} avis)</span>
                      </div>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Voir profil
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Price & Quantity */}
            <div className="space-y-4">
              <div className="flex items-baseline gap-4">
                <span className="text-3xl font-bold text-primary">
                  {product.price.toLocaleString()} FCFA
                </span>
                <span className="text-lg text-muted-foreground">
                  ${(product.price / 600).toFixed(2)}
                </span>
              </div>
              
              <div className="flex items-center gap-4">
                <label className="font-medium">{t.quantity}:</label>
                <div className="flex items-center border rounded-lg">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="px-4 py-2 min-w-[3rem] text-center">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button size="lg" className="flex-1 bg-primary hover:bg-primary/90">
                  {t.addToCart}
                </Button>
                <Button size="lg" variant="outline" className="flex-1 border-secondary text-secondary hover:bg-secondary hover:text-white">
                  {t.buyNow}
                </Button>
              </div>

              <div className="flex gap-4">
                <Button variant="ghost" size="sm">
                  <Heart className="h-4 w-4 mr-2" />
                  Favoris
                </Button>
                <Button variant="ghost" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Partager
                </Button>
              </div>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t">
              <div className="text-center">
                <Shield className="h-6 w-6 text-primary mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">{t.securePayment}</p>
              </div>
              <div className="text-center">
                <Truck className="h-6 w-6 text-primary mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">{t.fastDelivery}</p>
              </div>
              <div className="text-center">
                <Award className="h-6 w-6 text-primary mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">{t.qualityGuarantee}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mb-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">{t.description}</TabsTrigger>
              <TabsTrigger value="specifications">{t.specifications}</TabsTrigger>
              <TabsTrigger value="reviews">{t.reviews}</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {product.description}
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="specifications" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between py-2 border-b last:border-b-0">
                        <span className="font-medium">{key}</span>
                        <span className="text-muted-foreground">{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center text-muted-foreground">
                    Les avis clients seront affichés ici
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Similar Products */}
        <div>
          <h2 className="text-2xl font-bold mb-8 text-foreground">{t.similarProducts}</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {similarProducts.map(product => (
              <ProductCard
                key={product.id}
                {...product}
                onAddToCart={(id) => console.log('Added to cart:', id)}
              />
            ))}
          </div>
        </div>
      </div>

      <Footer language={language} />
    </div>
  );
}