import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CategoryCardProps {
  title: string;
  icon: LucideIcon;
  image: string;
  onClick?: () => void;
  className?: string;
}

export function CategoryCard({ title, icon: Icon, image, onClick, className = '' }: CategoryCardProps) {
  return (
    <Card 
      className={`group cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1 ${className}`}
      onClick={onClick}
    >
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <ImageWithFallback
            src={image}
            alt={title}
            className="w-full h-40 object-cover group-hover:scale-110 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-4 text-white">
            <Icon className="h-8 w-8 mb-2" />
            <h3 className="font-semibold text-lg">{title}</h3>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}