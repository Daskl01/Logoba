import { useState } from 'react';
import { Sprout, Droplets, Tractor, Package, ChevronRight } from 'lucide-react';
import { Header } from './components/Header';
import { CategoryCard } from './components/CategoryCard';
import { ProductCard } from './components/ProductCard';
import { TrustSection } from './components/TrustSection';
import { Footer } from './components/Footer';
import { Button } from './components/ui/button';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function App() {
  const [currentLanguage, setCurrentLanguage] = useState<'FR' | 'EN'>('FR');

  const translations = {
    FR: {
      hero: {
        title: 'Connecter la terre au digital',
        subtitle: 'La première marketplace africaine dédiée aux produits agricoles, intrants et équipements',
        cta: 'Découvrir les produits'
      },
      categories: {
        title: 'Nos catégories',
        items: [
          { name: 'Produits agricoles', icon: Sprout },
          { name: 'Intrants & engrais', icon: Droplets },
          { name: 'Matériel agricole', icon: Tractor },
          { name: 'Stockage & logistique', icon: Package }
        ]
      },
      popularProducts: {
        title: 'Produits populaires',
        viewAll: 'Voir tout'
      }
    },
    EN: {
      hero: {
        title: 'Connecting land to digital',
        subtitle: 'The first African marketplace dedicated to agricultural products, inputs and equipment',
        cta: 'Discover products'
      },
      categories: {
        title: 'Our categories',
        items: [
          { name: 'Agricultural products', icon: Sprout },
          { name: 'Inputs & fertilizers', icon: Droplets },
          { name: 'Agricultural equipment', icon: Tractor },
          { name: 'Storage & logistics', icon: Package }
        ]
      },
      popularProducts: {
        title: 'Popular products',
        viewAll: 'View all'
      }
    }
  };

  const t = translations[currentLanguage];

  const categoryImages = [
    "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1722044942164-9637e0452395?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWVkcyUyMGZlcnRpbGl6ZXIlMjBhZ3JpY3VsdHVyZXxlbnwxfHx8fDE3NTc5NDg3MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1685474442734-bb453f03060d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFjdG9yJTIwYWdyaWN1bHR1cmUlMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzU3OTQ4NzAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1740914994162-0b2a49280aeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXJlaG91c2UlMjBzdG9yYWdlJTIwbG9naXN0aWNzfGVufDF8fHx8MTc1Nzk0ODcwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  ];

  const products = [
    {
      id: '1',
      name: 'Cacao premium de Côte d\'Ivoire',
      price: 1200000,
      image: "https://images.unsplash.com/photo-1582082568487-628de573f601?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWNhbyUyMGJlYW5zJTIwY29jb2F8ZW58MXx8fHwxNzU3OTQ4Njk2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Abidjan, CI',
      badges: ['Bio', 'Certifié'],
      vendor: 'Coopérative SCAC'
    },
    {
      id: '2',
      name: 'Noix d\'anacarde calibrées',
      price: 850000,
      image: "https://images.unsplash.com/photo-1594900689460-fdad3599342c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXNoZXclMjBudXRzJTIwYW5hY2FyZGV8ZW58MXx8fHwxNzU3OTQ4Njk5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Bouaké, CI',
      badges: ['Export'],
      vendor: 'ANACARCI'
    },
    {
      id: '3',
      name: 'Tracteur Massey Ferguson 240',
      price: 15000000,
      image: "https://images.unsplash.com/photo-1685474442734-bb453f03060d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFjdG9yJTIwYWdyaWN1bHR1cmUlMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzU3OTQ4NzAzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Yamoussoukro, CI',
      badges: ['Neuf', 'Garantie'],
      vendor: 'AGRO-EQUIPCI'
    },
    {
      id: '4',
      name: 'Engrais NPK 15-15-15',
      price: 25000,
      image: "https://images.unsplash.com/photo-1722044942164-9637e0452395?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWVkcyUyMGZlcnRpbGl6ZXIlMjBhZ3JpY3VsdHVyZXxlbnwxfHx8fDE3NTc5NDg3MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      location: 'Abidjan, CI',
      badges: ['50kg'],
      vendor: 'FERTIL-CI'
    }
  ];

  const handleAddToCart = (productId: string) => {
    console.log('Added to cart:', productId);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        currentLanguage={currentLanguage} 
        onLanguageChange={(lang) => setCurrentLanguage(lang)}
      />

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1740741703636-1680d0c0f0a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwZmFybWVyJTIwYWdyaWN1bHR1cmV8ZW58MXx8fHwxNzU3OTQ4NjkyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Agriculture en Afrique"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/40" />
        </div>
        
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            {t.hero.title}
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            {t.hero.subtitle}
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg px-8 py-6">
            {t.hero.cta}
            <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">
            {t.categories.title}
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {t.categories.items.map((category, index) => (
              <CategoryCard
                key={category.name}
                title={category.name}
                icon={category.icon}
                image={categoryImages[index]}
                onClick={() => console.log('Navigate to category:', category.name)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Popular Products Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold text-foreground">
              {t.popularProducts.title}
            </h2>
            <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
              {t.popularProducts.viewAll}
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard
                key={product.id}
                {...product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        </div>
      </section>

      <TrustSection language={currentLanguage} />
      <Footer language={currentLanguage} />
    </div>
  );
}