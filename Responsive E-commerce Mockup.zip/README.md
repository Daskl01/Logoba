
  # Responsive E-commerce Mockup

  This is a code bundle for Responsive E-commerce Mockup. The original project is available at https://www.figma.com/design/uNWPhrClFPKHs79HRchwmk/Responsive-E-commerce-Mockup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  